#!/bin/bash

curl -Lso lib/parse.js https://www.parse.com/downloads/javascript/parse/latest/js
curl -Lso lib/parse.min.js https://www.parse.com/downloads/javascript/parse/latest/min.js
